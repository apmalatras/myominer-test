<?php
//Checks the hash from reldate at uniprot. It does not change the hash though if the file is dowloaded. It will change if all the processes are completed.
$env_var=getenv('OPENSHIFT_REPO_DIR');
$hashfile=md5_file("ftp://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/reldate.txt");
$checkhash=file("$env_var/uniprot_hashmd5.txt");

if ($hashfile!=$checkhash[0]){
	//uniprot version
	$getversion=file_get_contents("ftp://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/reldate.txt");
	$pattern="/20\d{2}_\d{2}/";
	preg_match($pattern,$getversion,$match);
	file_put_contents("$env_var/uniprot_version.txt",$match[0]);

	//Command to download uniprot to current directory
	$command="wget ftp://ftp.ebi.ac.uk/pub/databases/uniprot/knowledgebase/uniprot_sprot.dat.gz -P $env_var";
	echo "$command\n";
	exec($command);
	$out=fopen("$env_var/start_parsing_uniprot.txt","w");
	fwrite($out,"1");
	unlink("$env_var/output.txt");
	unlink("$env_var/output_GO.txt");
	unlink("$env_var/output_uni.txt");
	unlink("$env_var/mapping.txt");
	unlink("$env_var/gene_names.txt");
}
?>