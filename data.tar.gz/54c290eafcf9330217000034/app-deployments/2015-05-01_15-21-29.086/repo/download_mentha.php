<?php
//Checks the hash from reldate at Mentha. It does not change the hash though if the file is dowloaded. It will change if all the processes are completed.
$env_var=getenv('OPENSHIFT_REPO_DIR');

//Command to download Mentha to current directory
$command="wget -N mentha.uniroma2.it/dumps/organisms/all.zip -P $env_var";
exec($command);

$hashfile=md5_file("$env_var/all.zip");
$checkhash=file("$env_var/mentha_hashmd5.txt");

if ($hashfile!=$checkhash[0]){
	
	$out=fopen("$env_var/start_parsing_mentha.txt","w");
	fwrite($out,"1");
	unlink("$env_var/output_mentha.txt");
}
?>