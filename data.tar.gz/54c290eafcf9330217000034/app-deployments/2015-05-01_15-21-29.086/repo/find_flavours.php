<?php
$env_var=getenv('OPENSHIFT_REPO_DIR');

$flavours=scandir("$env_var/flavours");
$flavoursnum=count($flavours);


$out=fopen("$env_var/flavours_list.txt","w");

for($i=2;$i<$flavoursnum;$i++){
	fwrite($out,"$flavours[$i]\n");
}

?>