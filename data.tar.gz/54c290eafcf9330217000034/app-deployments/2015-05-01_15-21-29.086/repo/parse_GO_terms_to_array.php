<?php
//http://geneontology.org/ontology/go-basic.obo
$env_var_write=getenv('OPENSHIFT_DATA_DIR');
$env_var=getenv('OPENSHIFT_REPO_DIR');
//echo "$env_var_write\n";
$handle = fopen("http://geneontology.org/ontology/go-basic.obo", "r");
$handle_out = fopen("$env_var/output.txt", "r");
$handle_loc = fopen("$env_var/flavours/Generic_Flavour.txt", "r");
$output=fopen("$env_var/default_loc.txt", "w");

//go-basic.obo
//making a hash table for GO terms (key=GO term, value=GO name)
if ($handle) {
    while (($line_GO_terms = fgets($handle)) !== false) {
        // process the line read.
		
		$patternGO_ID="/^id\:\s{1}(.*)/";
		if(preg_match($patternGO_ID, $line_GO_terms, $match_GO_ID)){
			$temp_GO_ID=trim($match_GO_ID[1]);
		}
		$patternGO_name="/^name\:\s{1}(.*)/";
		if(preg_match($patternGO_name, $line_GO_terms, $match_GO_name)){
			$match_GO_name[1]=trim($match_GO_name[1]);
			$GO_terms[$temp_GO_ID]=$match_GO_name[1];
		}
    }
} else {
    // error opening the file.
	echo "error opening the file.";
}
//Localization_Generic_Flavour_NEW.txt
//making a hash table for generic localization table (key=first column fixed with only names, value = localization)
if ($handle_loc) {
    while (($line_loc = fgets($handle_loc)) !== false) {
        // process the line read.
		$explode_loc=explode("\t",trim($line_loc));
		//check for GO terms and replace with GO name
		$pattern_array_GO="/^GO/";
		if(preg_match($pattern_array_GO, $explode_loc[0], $match_array_loc)){
			$explode_loc[0]=$GO_terms[$explode_loc[0]];
			//Lowercase characters
			$explode_loc[0]=strtolower($explode_loc[0]);
			$loc_terms[$explode_loc[0]]=$explode_loc[2];
		}else{
			$explode_loc[0]=strtolower($explode_loc[0]);
			$loc_terms[$explode_loc[0]]=$explode_loc[2];
		}
    }
} else {
    // error opening the file.
}

//Unique locations

$array_uni=array_unique($loc_terms);
$array_uni_num=count($array_uni);


//MAIN
//this is the auto increment for the database
$ai=1;
$flag_id_first=1;
if ($handle_out) {
    while (($line_out = fgets($handle_out)) !== false) {
        // process the line read.
		$explode=explode("\t",trim($line_out));
		//to pick up the first line
		if($flag_id_first){
			$flag_id=$explode[0];
			$flag_id_first=0;
		}
		if($flag_id==$explode[0]){
			//check for GO terms and replace with GO name
			$pattern_array_GO="/^GO/";
			if(preg_match($pattern_array_GO, $explode[1], $match_array)){
				$explode[1]=$GO_terms[$explode[1]];
			}
			//Lowercase characters
			$explode[1]=strtolower($explode[1]);
			$explode_old=$explode[1];

			//HERE it changes with loc_term
			$explode[1]=$loc_terms[$explode[1]];

			//If there is no discription in Localization_Generic_Flavour_NEW.txt we give then Unknown loc
			if($explode[1]==""){
				$explode[1]="Unknown";
			}
			//////////////////////////////////////////////////////////
			//Here it checks if the unique locations exist inside the names of the locations from uniprot
			if($explode[1]=="Unknown"){
				foreach ($array_uni as $key => $value) {
					$value_low=strtolower($value);
					$pattern_array_uni="/($value_low?)/";
					if(preg_match($pattern_array_uni, $explode_old, $match_array)){
						//gets the larger in length string
						if($explode[1]!="Unknown" && strlen($explode[1])>strlen($value)){
						}else{
							$explode[1]=$value;
						}
					}
				}
			}
			//Add the number of the appearences in internal_array
			if(@array_key_exists($explode[1], $internal_array)){
				$internal_array[$explode[1]]++;
			}else{
				$internal_array[$explode[1]]=1;
			}
		}
		else{
			//Count the array number. In this case since we have shrink the array (depending on the keys) we will add the values
			$internal_array_num=0;
			foreach ($internal_array as $k => $v) {
				$internal_array_num+=$v;
			}
			asort($internal_array);
			$internal_array=array_reverse($internal_array);
			foreach ($internal_array as $k => $v) {
				fwrite($output,"$flag_id\t$k\t".round($v/$internal_array_num,2)."\n");
				//$ai++;
			}
			unset($internal_array);
			//The ID changes here
			$flag_id=$explode[0];
			//We redo this process, otherwise it will miss the line where the id changes
			//check for GO terms and replace with GO name
			$pattern_array_GO="/^GO/";
			if(preg_match($pattern_array_GO, $explode[1], $match_array)){
				$explode[1]=$GO_terms[$explode[1]];
			}
			//Lowercase characters
			$explode[1]=strtolower($explode[1]);
			$explode_old=$explode[1];

			//HERE it changes with loc_term
			$explode[1]=$loc_terms[$explode[1]];

			//If there is no discription in Localization_Generic_Flavour_NEW.txt we give then Unknown loc
			if($explode[1]==""){
				$explode[1]="Unknown";
			}
			//////////////////////////////////////////////////////////
			//Here it checks if the unique locations exist inside the names of the locations from uniprot
			if($explode[1]=="Unknown"){
				foreach ($array_uni as $key => $value) {
					$value_low=strtolower($value);
					$pattern_array_uni="/($value_low?)/";
					if(preg_match($pattern_array_uni, $explode_old, $match_array)){
						//gets the larger in length string
						if($explode[1]!="Unknown" && strlen($explode[1])>strlen($value)){
						}else{
							$explode[1]=$value;
						}
					}
				}
			}
			if(@array_key_exists($explode[1], $internal_array)){
				$internal_array[$explode[1]]++;
			}else{
				$internal_array[$explode[1]]=1;
			}
		}
    }
	
	//This is here to get the last uniprot ID
	//Count the array number. In this case since we have shrink the array (dependind of the keys) we will add the values
	$internal_array_num=0;
	foreach ($internal_array as $k => $v) {
		$internal_array_num+=$v;
	}
	asort($internal_array);
	$internal_array=array_reverse($internal_array);
	foreach ($internal_array as $k => $v) {
		fwrite($output,"$flag_id\t$k\t".round($v/$internal_array_num,2)."\n");
		//$ai++;
	}
	unset($internal_array);
} else {
    // error opening the file.
}

?>