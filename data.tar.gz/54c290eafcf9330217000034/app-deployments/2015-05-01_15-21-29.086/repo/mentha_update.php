<?php

$env_var=getenv('OPENSHIFT_REPO_DIR');

$checkhash=file_get_contents("$env_var/start_parsing_mentha.txt");
$checkhash=trim($checkhash);



if ($checkhash){
	echo "New Mentha Version found. Reading...\n";
	$out_mentha=fopen("$env_var/output_mentha.txt","w");
	$out_mentha_count=fopen("$env_var/output_mentha_count.txt","w");
	//OPEN THE ZIPED MENTHA FILE
	$z = new ZipArchive();
	if ($z->open("$env_var/all.zip")) {
		$nameindex = $z->getNameIndex(0); 
		$fp = $z->getStream("$nameindex");
		if(!$fp) exit("failed\n");
		//read the first line who we dont need
		$contents = fgets($fp);
		//MAIN BODY (parsing)
		while (!feof($fp)) {
			$line = fgets($fp);
			$expline=explode(";",$line);
			if(isset($expline[6])){
				fwrite($out_mentha,"$expline[0]\t$expline[2]\t$expline[3]\t$expline[5]\t$expline[6]\n");
				if(isset($count_arr[$expline[0]])){
					$count_arr[$expline[0]]+=1;
				}else{
					$count_arr[$expline[0]]=1;
				}
				if(isset($count_arr[$expline[3]])){
					$count_arr[$expline[3]]+=1;
				}else{
					$count_arr[$expline[3]]=1;
				}
			}
		}
		
		foreach($count_arr as $key=>$value){
			fwrite($out_mentha_count,"$key\t$value\n");
		}
		
		fclose($fp);
		
		file_put_contents("$env_var/mentha_version.txt",$nameindex);
		//closing
		$hashfile=md5_file("$env_var/all.zip");
		//The hash is updated so it stops the download_uniprot.php script
		$oldhash=fopen("$env_var/mentha_hashmd5.txt", "w");
		fwrite($oldhash, $hashfile);
		//deletes the uniprot
		unlink("$env_var/all.zip");
		//Here stops the uniport_daily_update.php script
		$activation=fopen("$env_var/start_parsing_mentha.txt", "w");
		fwrite($activation, "0");
		
		
		
		echo "done.\n";
	}

}else{
	echo "Mentha is already updated!\n";
}




?>