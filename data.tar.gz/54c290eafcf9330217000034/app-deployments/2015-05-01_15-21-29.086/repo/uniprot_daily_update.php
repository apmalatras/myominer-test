<?php

//ftp://ftp.ebi.ac.uk/pub/databases/uniprot/knowledgebase/uniprot_sprot.dat.gz
//md5 hash that checks for a new Uniprot version
$env_var_write=getenv('OPENSHIFT_DATA_DIR');
$env_var=getenv('OPENSHIFT_REPO_DIR');

$checkhash=file_get_contents("$env_var/start_parsing_uniprot.txt");
$checkhash=trim($checkhash);

$k=0;
if ($checkhash){
	echo "New Uniprot Version found. Reading...\n";
	//Parsing//
	//Reads the Uniprot dat file (line by line)//
	//Directory of the uniprot file
	$filedir="$env_var/uniprot_sprot.dat.gz";
	
	//Open the output file
	$out=fopen("$env_var/output.txt", "a");
	$out_GO=fopen("$env_var/output_GO.txt", "a");
	$out_uni=fopen("$env_var/output_uni.txt", "a");
	$out_map=fopen("$env_var/mapping.txt", "a");
	$out_gn=fopen("$env_var/gene_names.txt", "a");
	
	//This is the file that has the current entries for while
	$linesparsed=fopen("$env_var/lines_parsed.txt", "r+");
	$lastentry=fgets($linesparsed);
	$lastentry=trim($lastentry);
	$lastentrytoadd=$lastentry;
	//Unzip the file
	$handle = gzopen("$filedir", "r");
	//flags to catch next lines in CC SUBCELLULAR LOCALIZATION, and to terminate findings (lazy) on the rest
	$flag_CC=0;
	$flag_AC=1;
	$flag_ID=1;
	$flag_OS=1;
	$flag_GN=1;
	$flag_ET=1;
	$flag_EN=1;
	$flag_hash=0;
	//delimiters for multiexplode function
	$delim=array(",",".",";",":");
	/*//Auto increment for db
	//GO
	$linecount_go=0;
	$opencount_go = fopen("$env_var/output_GO.txt", "r");
	while(!feof($opencount_go)){
	  $line_go = fgets($opencount_go);
	  $linecount_go++;
	}
	fclose($opencount_go);
	$ai_go=$linecount_go++;
	//Uniprot
	$linecount_uni=0;
	$opencount_uni = fopen("$env_var/output_uni.txt", "r");
	while(!feof($opencount_uni)){
	  $line_uni = fgets($opencount_uni);
	  $linecount_uni++;
	}
	fclose($opencount_uni);
	$ai_uni=$linecount_uni;
	//Gene name
	$linecount_gn=0;
	$opencount_gn = fopen("$env_var/gene_names.txt", "r");
	while(!feof($opencount_gn)){
	  $line_gn = fgets($opencount_gn);
	  $linecount_gn++;
	}
	fclose($opencount_gn);
	$ai_gn=$linecount_gn;*/
	//Line by line reading
	$EN="";
	if ($handle) {
		//how many entries each time
		while ($k<200000)  {
			$line=fgets($handle);
			if($lastentry>$k){
				if($line=="//\n"){
					$lastentry--;
				}
			}else{
				//Check for empty line or else eof (because uniprot does not have empty lines
				if($line==""){
					ftruncate($linesparsed,0);
					rewind($linesparsed);
					fwrite($linesparsed,"0");
					$flag_hash=1;
					break;
				}
				// process the line read.
				//REGEX for the AC
				$patternAC="/^AC\s{3}(.+?);/";
				if($flag_AC){
					if(preg_match($patternAC, $line, $matchAC)){
						$AC=$matchAC[1];
						$flag_AC=0;
					}
				}
				//REGEX for the ID
				$patternID="/^ID\s{3}(.+?)\s/";
				if($flag_ID){
					if(preg_match($patternID, $line, $matchID)){
						$ID=$matchID[1];
						$flag_ID=0;
					}
				}
				//REGEX for the OS
				$patternOS="/^OS\s{3}(.*?)[\(|\.]/";
				if($flag_OS){
					if(preg_match($patternOS, $line, $matchOS)){
						$OS=$matchOS[1];
						$OS=trim($OS, " ");
						$flag_OS=0;
					}
				}
				//REGEX for the GN
				$patternGNbegin="/^GN\s{3}.+?/";
				if(preg_match($patternGNbegin, $line, $matchGNbegin)){
					$patternGN="/=(.+?)[\{|;]/";
					if(preg_match_all($patternGN, $line, $matchGN)){
						//$GN=$matchGN[0][0];
						$matchGNnum=count($matchGN[1]);
						for($i=0;$i<$matchGNnum;$i++){
							//echo "$AC\t$matchGN[1][$i]\n";
							$explodeGN=explode(",",$matchGN[1][$i]);
							$explodeGNnum=count($explodeGN);
							//TOLEN change 23/01/2015 pairnei mono ta prwta 2 gene names gia oikonomia xorou
							for($j=0;$j<1;$j++){							
								$gene_normal=trim($explodeGN[$j]);
								$gene_normal=trim($gene_normal,"\"");
								$explodeGN[$j]=strtoupper($gene_normal);
								fwrite($out_gn, "$AC\t$explodeGN[$j]\t$gene_normal\n");
								//$ai_gn++;
							}
							$explodeGN="";
						}
					}
				}
				$matchGN="";
				
				//REGEX for the EN
				$patternEN="/^DR\s{3}Ensembl.*?;.*?;.*?;\s{1}(.+?)\.\s/";
				if($flag_EN){
					if(preg_match($patternEN, $line, $matchEN)){
						$EN.=$matchEN[1];
						//$flag_EN=0;
					}
				}
				//REGEX for the ET
				$patternET="/^DR\s{3}GeneID;\s{1}(.+?);\s/";
				if($flag_ET){
					if(preg_match($patternET, $line, $matchET)){
						$ET=$matchET[1];
						$flag_ET=0;
					}
				}
				//REGEX for GO
				$patternGO="/^DR\s{3}GO\;\s{1}(GO\:\d{7})\;\s{1}C/";
				if(preg_match($patternGO, $line, $matchGO)){
					$GO=$matchGO[1];
					//output GO
					fwrite($out, "$AC\t$GO\n");
					fwrite($out_GO, "$AC\t$GO\n");
					//$ai_go++;
				}
				//REGEX for lines after CC SUBCELLULAR LOCATION
				$patternSTOP="/^CC\s{6}/";
				if ($flag_CC && preg_match($patternSTOP, $line, $m) && isset($subloc)){
					$subloc.=" ".trim(substr("$line",9,strlen($line)));
					$subloc = preg_replace('/\s+/', ' ',$subloc);
					//echo "$subloc\n";
				}else if(isset($subloc)){
					$flag=0;
					//Removes {ECO..} statements
					$patternREP="/\{.*?\}/";
					$subloc=trim(preg_replace($patternREP, "", $subloc));
					$arr=multiexplode($delim,$subloc);
					$arrnum=count($arr);
					for ($i=0;$i<$arrnum;$i++){
						$arr[$i]=trim($arr[$i]);
						$patternNote=("/^Note.*/i");
						if($arr[$i]==NULL){
						}else if(preg_match($patternNote,$arr[$i],$matchnote)){
							break;
						}else{
							//output SUBCELLULAR LOCATION
							fwrite($out, "$AC\t$arr[$i]\n");
							fwrite($out_uni, "$AC\t$ID\t$arr[$i]\n");
							//$ai_uni++;
						}
					}
					$subloc=NULL;
				}
				//REGEX for CC SUBCELLULAR LOCATION
				$patternCC="/^CC\s{3}-!-\s{1}SUBCELLULAR\s{1}LOCATION\:\s{1}(.*)/";
				if(preg_match($patternCC, $line, $matchCC)){
					//echo "$matchCC[1]\n";
					$subloc=trim($matchCC[1]);
					$flag_CC=1;
				}
				
				//Uniprot's EOF. Reseting the flags
				if($line=="//\n"){
					fwrite($out_map, "$AC\t$ID\t$OS\t$EN\t$ET\n");
					$flag_AC=1;
					$flag_ID=1;
					$flag_OS=1;
					$flag_GN=1;
					$flag_EN=1;
					$flag_ET=1;
					$AC="";
					$ID="";
					$OS="";
					$EN="";
					$ET="";
					$k++;
					//echo "\rEntries completed: $k";
					//Because we neven know if a kill will happen randomly
					ftruncate($linesparsed,0);
					rewind($linesparsed);
					fwrite($linesparsed,$lastentrytoadd+$k);
				}	
			}
		}
	} else {
		// error opening the file.
		echo "error opening the file.";
		exit();
	} 

	fclose($handle);
	if ($flag_hash){
		//Get the default_loc.txt
		include ("parse_GO_terms_to_array.php");
		include ("parse_GO_terms_to_array_go.php");
		include ("parse_GO_terms_to_array_uni.php");
		//Write the new hash number to the file
		$hashfile=md5_file("ftp://ftp.uniprot.org/pub/databases/uniprot/current_release/knowledgebase/complete/reldate.txt");
		//The hash is updated so it stops the download_uniprot.php script
		$oldhash=fopen("$env_var/uniprot_hashmd5.txt", "w");
		fwrite($oldhash, $hashfile);
		//deletes the uniprot
		unlink("$env_var/uniprot_sprot.dat.gz");
		//Here stops the uniport_daily_update.php script
		$activation=fopen("$env_var/start_parsing_uniprot.txt", "w");
		fwrite($activation, "0");
	}
}else{
	echo "Identical Uniprot version. Closing..";
}

//Explode with multiple delimiters (. , : ;)
function multiexplode ($delimiters,$string) {
	$ready = str_replace($delimiters, $delimiters[0], $string);
	$launch = explode($delimiters[0], $ready);
	return  $launch;	
}
?>